package com.genpact.coe.spritrider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavathonexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
