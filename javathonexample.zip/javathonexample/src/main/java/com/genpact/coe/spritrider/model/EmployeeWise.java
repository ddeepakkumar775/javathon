package com.genpact.coe.spritrider.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "employee_wise")
public class EmployeeWise {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected int id;

	protected long ohrId;

	protected long parentOhrId;

	protected String name;

	protected String role;

	@Transient
	protected List<EmployeeWise> listEmployeeWise;

	public EmployeeWise() {
	}

	public EmployeeWise(int id, long ohrId, long parentOhrId, String name, String role) {
		super();
		this.id = id;
		this.ohrId = ohrId;
		this.parentOhrId = parentOhrId;
		this.name = name;
		this.role = role;
	}

	public EmployeeWise(long ohrId, long parentOhrId, String name, String role) {
		super();
		this.ohrId = ohrId;
		this.parentOhrId = parentOhrId;
		this.name = name;
		this.role = role;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getOhrId() {
		return ohrId;
	}

	public void setOhrId(long ohrId) {
		this.ohrId = ohrId;
	}

	public long getParentOhrId() {
		return parentOhrId;
	}

	public void setParentOhrId(long parentOhrId) {
		this.parentOhrId = parentOhrId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<EmployeeWise> getListEmployeeWise() {
		return listEmployeeWise;
	}

	public void setListEmployeeWise(List<EmployeeWise> listEmployeeWise) {
		this.listEmployeeWise = listEmployeeWise;
	}

	@Override
	public String toString() {
		return "EmployeeWise [id=" + id + ", ohrId=" + ohrId + ", parentOhrId=" + parentOhrId + ", name=" + name
				+ ", role=" + role + ", listEmployeeWise=" + listEmployeeWise + "]";
	}

}
