package com.genpact.coe.spritrider.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.coe.spritrider.model.EmployeeWise;
import com.genpact.coe.spritrider.service.EmployeeWiseService;

@RestController
public class EmployeeWiseController {

	@Autowired
	private EmployeeWiseService employeeWiseService;

	/*
	 * @GetMapping("/getAllEmployeeWise") public List<EmployeeWise> getAllEmployee()
	 * { return employeeWiseService.getAllEmployeeWise(); }
	 */

	@GetMapping("/getAllEmployeeWise")
	public List<EmployeeWise> getAllEmployee() {
		return employeeWiseService.getAllEmployeeWise();
	}
}
