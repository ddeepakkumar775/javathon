package com.genpact.coe.spritrider.controller;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.genpact.coe.spritrider.model.EmployeeWise;
import com.genpact.coe.spritrider.service.EmployeeWiseService;

@RestController
public class EmployeeWiseController {

	@Autowired
	private EmployeeWiseService employeeWiseService;

	@GetMapping("/getAllEmployeeWise")
	public List<EmployeeWise> getAllEmployeeWise() {
		return employeeWiseService.getAllEmployeeWise();
	}

	@GetMapping("/getAllEmployee")
	public List<EmployeeWise> getAllEmployee() {
		return employeeWiseService.getAllEmployee();
	}

	@PostConstruct
	public void loadJson() throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();

		List<EmployeeWise> employeeWises = (List<EmployeeWise>) objectMapper
				.readValue(new ClassPathResource("dummydata.json").getFile(), new TypeReference<List<EmployeeWise>>() {
				});
		int loadDataSize = employeeWiseService.loadData(employeeWises);
		System.out.println("total data loaded is : " + loadDataSize);
	}
}
