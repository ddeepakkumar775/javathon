package com.genpact.coe.spritrider.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.genpact.coe.spritrider.model.EmployeeWise;

@Repository
public interface EmployeeWiseRepository extends JpaRepository<EmployeeWise, Integer> {

}
