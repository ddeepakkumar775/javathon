package com.genpact.coe.spritrider.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.coe.spritrider.model.EmployeeWise;
import com.genpact.coe.spritrider.repository.EmployeeWiseRepository;

@Service
public class EmployeeWiseService {

	@Autowired
	private EmployeeWiseRepository employeeWiseRepository;

	public List<EmployeeWise> getAllEmployeeWise() {
		List<EmployeeWise> allEmployeeWise = employeeWiseRepository.findAll();
		return employeeWiseFilter(0,allEmployeeWise);
	}

	public List<EmployeeWise> employeeWiseFilter(long ohrId, List<EmployeeWise> employeeWises) {
		EmployeeWise employeeWise = null;

		List<EmployeeWise> employeeWisesList = new ArrayList<EmployeeWise>();

		for (EmployeeWise employeeWise2 : employeeWises) {
			if (ohrId == employeeWise2.getParentOhrId()) {
				employeeWise = new EmployeeWise();
				employeeWise.setId(employeeWise2.getId());
				employeeWise.setName(employeeWise2.getName());
				employeeWise.setOhrId(employeeWise2.getOhrId());
				employeeWise.setParentOhrId(employeeWise2.getParentOhrId());
				employeeWise.setRole(employeeWise2.getRole());
				List<EmployeeWise> employeeWisesChildList = employeeWiseFilter(employeeWise2.getOhrId(), employeeWises);
				employeeWise.setListEmployeeWise(employeeWisesChildList != null ? employeeWisesChildList : null);
				employeeWisesList.add(employeeWise);
			}

		}
		return employeeWisesList;
	}

}
